export class Request {
    cargaPrevista;
    id;
    massaPonte;
    nome;
    constructor() {
        this.cargaPrevista = 0;
        this.id = 0;
        this.massaPonte = 0;
        this.nome = "";
    }
}

const a = new Request();